import os
import ReadData
import datetime

#making the function to display the detail about shop to customer 
def mainFrame():
    os.system('cls')
    print(''' 
    
    
             _  __           _   _                    ____  _                  
            | |/ /__ _ _ __ | |_(_)_ __  _   _ _ __  / ___|| |__   ___  _ __   
            | ' // _` | '_ \| __| | '_ \| | | | '__| \___ \| '_ \ / _ \| '_ \  
            | . \ (_| | | | | |_| | |_) | |_| | |     ___) | | | | (_) | |_) | 
            |_|\_\__,_|_| |_|\__|_| .__/ \__,_|_|    |____/|_| |_|\___/| .__/  
                                  |_|                                  |_|     

    
    
    
    ''')

    print('''
    
                       -------------Welcome to Kantipur Shop----------------
                     
                       || ********* Enter 1 to Show the table   **********||
                       || ********* Enter 2 to  Sell Laptop     **********||
                       || ********* Enter 3 to Buy From Vendor  **********||
                       || ********* Enter 4 to Exit the Program **********||
                     ---------------------------------------------------------
                       

    
    
    
    ''')
#making the function of stockTable
def provide_StockTable():
    os.system("cls")


    print('*------------------Displaying..............*')
    print('-------------------------------------------------------------------------------------------------------------')
    print("||S.N  | Item Name\t| Brand \t | Price\t| Quantity   |Processor       |Graphics Card      ||")
    print('-------------------------------------------------------------------------------------------------------------')
    
    #calling the function of stockFile from ReadData
    stock_data = ReadData.stockFile()
    for i in range (len(stock_data)):
        component = stock_data[i]
        print('||',end='')
        print(str(i+1).ljust(5),component[0].ljust(15),component[1].ljust(15),component[2].ljust(12),component[3].ljust(12),component[4].ljust(15),component[5].ljust(15)+'    ||',sep='||') 
        print('-----------------------------------------------------------------------------------------------------------')       

def sellList():
    print('''
                   
                                 -------------    Kantipur Shop     ---------------------
                                 |                                                      |
                                 -****  Enter 1 - 5 To Buy Item From Above list   *****-
                                 |                                                      |
                                 --------------------------------------------------------
    
    
    ''')
#making the function of errorMessage
def errorMessage():
    print("""
            _____   _                           ______         _               __      __     _  _      _   _____                       _   
           |  __ \ | |                         |  ____|       | |              \ \    / /    | |(_)    | | |_   _|                     | |  
           | |__) || |  ___   __ _  ___   ___  | |__    _ __  | |_  ___  _ __   \ \  / /__ _ | | _   __| |   | |   _ __   _ __   _   _ | |_ 
           |  ___/ | | / _ \ / _` |/ __| / _ \ |  __|  | '_ \ | __|/ _ \| '__|   \ \/ // _` || || | / _` |   | |  | '_ \ | '_ \ | | | || __|
           | |     | ||  __/| (_| |\__ \|  __/ | |____ | | | || |_|  __/| |       \  /| (_| || || || (_| |  _| |_ | | | || |_) || |_| || |_ 
           |_|     |_| \___| \__,_||___/ \___| |______||_| |_| \__|\___||_|        \/  \__,_||_||_| \__,_| |_____||_| |_|| .__/  \__,_| \__|
                                                                                                                         | |                
                                                                                                                         |_|                
    
    
    
    """)
    input("               PRESS ENTER TO CONTINUE!!"   )


def buyMore():
     print("""
                         (1) Buy More
                         (2) back to table    
     
     
     
     
     """) 
#making the function of exit 
def exit():
    print("""
           |-----------------------------------------------------|
           *               Thank You !!                          *
                          For choosing us  
           *                                                     *   
           |-----------------------------------------------------|
    
    """)

#making the bill for customer
def bill_maker(c_Nme, c_Address, c_PhoneNumber, u_Demand, u_Choice, stk_Data, allPrice):
    if(os.path.exists(c_Nme + "Bill.txt")):
        file = open(c_Nme + "Bill.txt", "a")
        file.write(f"""
+--------------------------------------------------------------------------------------------------+                       
|        Laptop Name     :   {stk_Data[int(u_Choice)][0]:<20}                                      
|        Laptop Brand    :   {stk_Data[int(u_Choice)][1]:<10}                                      
|        Price           :   {stk_Data[int(u_Choice)][2]:<10}                                      
|        Quantity        :   {u_Demand:<10}                                                        
+--------------------------------------------------------------------------------------------------+                       
|        Total Amount    :   ${allPrice:<10}                                                       
                       """)
        file.close
    else:
        file = open(c_Nme + "Bill.txt", "w")
        file.write(f"""
+--------------------------------------------------------------------------------------------------+                       
|                                  kantipur Shop                                                   
|                        Buddha chowk,  Pokhara-10                                                 
|                 Phone: 061-123453 Email: info@kantipurshop.com                                   
+--------------------------------------------------------------------------------------------------+                       
|                                                            Date    : {datetime.datetime.now()}   
|        Customer Name   :   {c_Nme:<10}                                                           
|        Customer Address:   {c_Address:<10}                                                       
|        Customer Contact:   {c_PhoneNumber:<10}                                                   
+--------------------------------------------------------------------------------------------------+                                                             
|        Laptop Name     :   {stk_Data[int(u_Choice)][0]:<20}                                      
|        Laptop Brand    :   {stk_Data[int(u_Choice)][1]:10}                                       
|        Price           :   {stk_Data[int(u_Choice)][2]:<10}                                      
|        Quantity        :   {u_Demand:<10}                                                        
+--------------------------------------------------------------------------------------------------+                       
|        Total Amount    :   ${allPrice:<10}                                                       
                       """)
        file.close
#making the function of bill to the vender 
def vendor_maker(u_Demand, u_Choice, v_Nme, stk_Data, allPrice):
    if(os.path.exists(v_Nme + "Bill.txt")):
        file = open(v_Nme + "Bill.txt", "a")
        file.write(f"""
+--------------------------------------------------------------------------------------------------+                       
|        Laptop Name     :   {stk_Data[int(u_Choice)][0]:<20}                                      
|        Laptop Brand    :   {stk_Data[int(u_Choice)][1]:<10}                                      
|        Price           :   {stk_Data[int(u_Choice)][2]:<10}                                      
|        Quantity        :   {u_Demand:<10}                                                        
+--------------------------------------------------------------------------------------------------+                       
|        Total Amount    :   ${allPrice:<10}                                                       
                       """)
        file.close
    else:
        file = open(v_Nme + "Bill.txt", "w")
        file.write(f"""
+--------------------------------------------------------------------------------------------------+                       
|                                       kantipur Shop                                              
|                        Buddha chowk,  Pokhara-10                                                 
|                 Phone: 061-123453 Email: info@kantipurshop.com                                   
+--------------------------------------------------------------------------------------------------+                       
|                                                            Date    :{datetime.datetime.now()}    
|        Vendor Name   :   {v_Nme:<10}                                                             
+--------------------------------------------------------------------------------------------------+                                                             
|        Laptop Name     :   {stk_Data[int(u_Choice)][0]:<20}                                      
|        Laptop Brand    :   {stk_Data[int(u_Choice)][1]:10}                                       
|        Price           :   {stk_Data[int(u_Choice)][2]:<10}                                     
|        Quantity        :   {u_Demand:<10}                                                        
+--------------------------------------------------------------------------------------------------+                       
|        Total Amount    :   ${allPrice:<10}                                                       
                       """)
        file.close
 #making the final calculate of amount or grandtotal           
def addfinalTotal(c_name, Total): 
    file = open(c_name + "Bill.txt" , "a")
    file.write(f"""                    
|                                                            Shipping Cost   :  1200               
+--------------------------------------------------------------------------------------------------+                       
|        Grand Total     :   {Total + 1200:<10}                                                    
+--------------------------------------------------------------------------------------------------+                      
        """)
    file.close

                

        
           





