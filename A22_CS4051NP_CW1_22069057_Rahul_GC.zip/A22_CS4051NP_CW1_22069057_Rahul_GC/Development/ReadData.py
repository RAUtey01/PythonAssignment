
def stockFile():
    data = []
    file = open('stock.txt','r')
    lines = file.readlines()
    for i in range (len(lines)):
        data.append(lines[i].strip('\n').split(","))
    file.close
    return data


