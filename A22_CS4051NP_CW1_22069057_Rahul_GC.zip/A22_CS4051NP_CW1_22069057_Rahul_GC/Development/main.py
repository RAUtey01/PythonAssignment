import executeGUI
import operation



while True:
    # showing the detail or option about shop to the customer. 
    executeGUI.mainFrame()
    try:

        
        userInput = input ("choose from (1-4):")

        if (userInput == "1"):
            #calling the fuction of StockTable from executeGUI
            executeGUI.provide_StockTable()
            input("Press Enter To Continue")
        elif(userInput=="2"):
            #calling the function of sell_to_client from operation
            operation.sell_to_client()
        elif(userInput=="3"):
            #calling the function of by_from _dealer from operation
            operation.buy_from_dealer()
        elif(userInput=="4"):
            #calling the function of exit from execute
            executeGUI.exit()
            break
        else:
            #calling the function of errormessage from execute
            executeGUI.errorMessage()
    except:
        # if cilent input except from 1 to 4 then message display in the screen
        print("Please Enter a valid number")
        input()            

