import ReadData
#making the function of refillstock 
def refillStock(newQuantity,selectedchoice):
    stockData = ReadData.stockFile()
    stockData[int(selectedchoice)][3] = " " +str(int(stockData[int(selectedchoice)][3]) + int(newQuantity))
    write_stockData_to_file(stockData)
#making the function of changeStock 
def changeStock(newQuantity, selectedchoice):
    stockData = ReadData.stockFile()
    stockData[int(selectedchoice)][3] = " " +str(int(stockData[int(selectedchoice)][3]) - int(newQuantity))
    write_stockData_to_file(stockData)
    
def write_stockData_to_file(stockData):
    stockData_str = ""
    for sublist in stockData:
        line = ""
        for item in sublist:
            line += str(item) + ","
        line = line.rstrip(",") + "\n"
        stockData_str += line
    file = open("stock.txt", "w")
    file.write(stockData_str)  
    file.close

def read_Data(c_name):
    bill = open(c_name + "Bill.txt","r")
    print(bill.read())
    bill.close

def read_VData(v_Nme):
    bill = open(v_Nme + "Bill.txt","r")
    print(bill.read())
    bill.close















