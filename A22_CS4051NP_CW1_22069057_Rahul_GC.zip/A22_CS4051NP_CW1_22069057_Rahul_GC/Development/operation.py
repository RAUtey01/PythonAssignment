import ReadData
import executeGUI
import write

Total = 0
#making the function for buying fro vendor
def buy_from_dealer():
    first = True
    buyAgain = True
    while first:
        try:
            v_Nme  = input("Enter Company Name: ")
        except:
            print("Please Enter A valid Name")  
            
        if (len(v_Nme) > 0):
            while buyAgain:
                #calling the function of stocktable from the executeGUI
                executeGUI.provide_StockTable()
                try:
                    u_Choice = int(input("Enter Your Choice:"))
                    u_Demand = int(input("Enter Number of Laptops: "))
                except:
                    input("Please Enter A number")

                u_Choice = u_Choice - 1
                
                if(u_Choice >= 0 and u_Choice < 5 and u_Demand > 0):
                    #calling the function of stockfile from ReadData
                    stk_Data = ReadData.stockFile()
                    price = stk_Data[u_Choice][2].replace("$","")
                    allPrice = int(price) * u_Demand
                    global Total
                    Total += allPrice
                    #calling the function refillstock from write
                    write.refillStock(u_Demand, u_Choice)
                    #calling the bill for vendor from the executeGUI
                    executeGUI.vendor_maker(u_Demand, u_Choice, v_Nme, stk_Data, allPrice)
                    
                    while True:
                        try:
                            v_selection  = input("Enter yes or no?")
                            v_selection = v_selection.lower()
                        except:
                            print("Do as instructed yes or no?")

                        if (v_selection == "yes"):
                            print("continue for buying")
                            break
                        elif (v_selection == "no"):
                            write.read_VData(v_Nme)
                            print("Thank You")
                            input()
                            buyAgain = False
                            first = False   
                            break
                        else:
                            input("Do as instructed?")
                else:
                    input("Choose the serial number as shown in above table")
        else:
            input("Please enter your name")
#making the function of selling the laptop to customer             
def sell_to_client():
    first = True
    sellAgain = True
    while first:
        try:
            c_Nme  = input("Enter Name: ")
            c_Address = input("Enter Addres ")
            c_PhoneNumber = int(input("Enter Phone Number "))
            #calling the stocktable from executeGUI
            executeGUI.provide_StockTable()
            executeGUI.sellList()
            if (len(c_Nme) > 0 and len(c_Address) > 0 and len(str(c_PhoneNumber)) > 0):
                while sellAgain:
                    c_PhoneNumber = int(c_PhoneNumber)

                    try:
                        u_Choice = int(input("Enter Your Choice:"))
                        u_Demand = int(input("Enter Number of Laptops: "))
                   
                        u_Choice = u_Choice - 1

                        if(u_Choice >= 0):
                            #calling the function stockFile from ReadData 
                            stk_Data = ReadData.stockFile() 
                            if(u_Demand < int(stk_Data[int(u_Choice)][3])):
                                if(int(stk_Data[int(u_Choice)][3])) >= 0 and int(u_Choice) >=0 :
                                    price = stk_Data[u_Choice][2].replace("$","")
                                    allPrice = int(price) * u_Demand
                                    global Total
                                    Total += allPrice
                                    # calling the function changeStock from write                   
                                    write.changeStock(u_Demand, u_Choice)
                                    #calling the selling bill from execute
                                    executeGUI.bill_maker(c_Nme, c_Address, c_PhoneNumber, u_Demand, u_Choice, stk_Data, Total)
                                    #The provided code snippet prompts the user to enter either "Yes" or "No"
                                    while True:
                                        try:
                                            v_selection  = input("Enter Yes or No?")
                                            #converts the input to lowercase
                                            v_selection = v_selection.lower()
                                        except:
                                            print("Please enter a valid number")
                                        
                                        if (v_selection == "yes"):
                                            print("thankyou for purchasing here")
                                            break
                                        elif (v_selection == "no"):
                                            #calling the the addfinalTotal function from executeGUI
                                            executeGUI.addfinalTotal(c_Nme, Total)
                                            #calling read_Data function from write
                                            write.read_Data(c_Nme)
                                            print("Thank You")
                                            input()
                                            sellAgain = False
                                            first = False 
                                            break
                                        else:
                                            print("DO as instructed ?")
                                else:
                                    print("Invalid input")
                            else:
                                print("OUT OF STOCK")
                        else:
                            print("Please Enter A Valid Input")
                    except:
                        print("please choose the number from  1 to 5  ")
            else:
                print("invalid")
        except:
            print("Please Enter a Valid Input")
Total = 0
            

                
                
                
            
            
            
